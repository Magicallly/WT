<a href="upload.php">Добавление</a><br>
<a href="move.php">Перемещение</a>
<a href="delete.php">Удаление</a><br>