<form action="movea.php" method="POST">
    Файл: <input type="text" name="full_filename" /><br><br>
    Новая директория: <input type="text" name="new_directory" /><br><br>
    <input type="submit" value="Переместить!">
</form>