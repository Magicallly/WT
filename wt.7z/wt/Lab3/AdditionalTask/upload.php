<form enctype="multipart/form-data" action="uploada.php" method="post">
    Файл для загрузки: <input type="file" name="file"><br><br>
    Куда сохранить: <input type="text" name="dir"><br><br>
    <input type="submit" name="u_button" value="Загрузить">
</form>