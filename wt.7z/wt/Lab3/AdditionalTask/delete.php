<form action="deletea.php" method="POST">
    Путь к файлу: <input type="text" name="full_filename" /><br><br>
    <input type="submit" value="Удалить!">
</form>