<?php
    $hello = "CONFIG var value";