<?php
    $VARS['hello'] = "Test string VAR."; 